# Sable v101.0 — Calculation Workbench

## Product direction
Sable is rebuilt as a question-first calculation workbench. It is not a keypad skin or a visual copy of a single competitor. The v101.0 interface replaces the earlier blue/navy and warm-paper shells, old drawer-first controls, tile dashboard, and separate Saved navigation destination.

## New information architecture
- **Compute:** open calculation canvas, adaptive expression/result display and a tactile keypad.
- **Library:** a searchable, single-column task index grouped by Convert, Finance, Math and Daily.
- **Trail:** calculation history with reuse and management actions.
- **Studio:** themes, number formatting, startup behavior, feedback, privacy and accessibility preferences.
- Saved tools remain available inside Library; there is no Saved bottom tab or legacy drawer entry point.

## Visual system
- Light palette: porcelain `#f2f5f0`, deep forest ink `#17231f`, signal-lime action `#c8e85b`.
- Dark palette: forest charcoal `#121c18`, soft green surfaces, warm-white text and lime action.
- Six selectable accent palettes: Signal Lime, Field Moss, Mist Stone, Iris, Saffron and Lagoon.
- Calculation display is an open canvas rather than an outlined/rounded display card.
- Library uses an editorial list, category filters and intent descriptions rather than a grid of tiles.
- Shared semantic tokens cover keypad, forms, result panels, dialogs, navigation, settings and history.
- Small-screen, short-height, safe-area, reduced-motion and keyboard focus rules are retained.

## Tool inventory — 24 workspaces
- Convert: Currency, Unit, Fuel Efficiency.
- Finance: Discount, Sales Tax, Loan, Savings, Tip, Unit Price, Bill Split, Compound Growth, Markup & Margin, Choice Compare.
- Math: Percentage, Grade Average, Hexadecimal, Scientific, Ratio Split, Quick Statistics.
- Daily: Body Metrics, Date, Fuel Cost, World Time, Time Span.

## New differentiating calculator
**Choice Compare** compares two alternatives over the same whole-month horizon. It combines upfront and recurring costs, shows each total, the lower-cost option, the absolute difference and the theoretical crossover month where the two cost curves meet. Inputs are bounded and validated; calculations remain local.

## Engine and compatibility strategy
The presentation layer and navigation are replaced. Existing arithmetic, scientific, unit, currency provider/refresh, date, finance and history calculation engines remain the compatibility core so working calculation behavior is not discarded. Seven additional standalone calculators are testable in `assets/js/sable-calculators.js`: Bill Split, Compound Growth, Markup & Margin, Ratio Split, Quick Statistics, Time Span and Choice Compare.

## Research basis
Public product descriptions and official help/store pages for 23+ calculator products were reviewed. The evidence is desk research, not identical-device hands-on benchmarking. See `RESEARCH-24-CALCULATOR-APPS-v101.0.md` for the product set, comparison signals, design decisions and source links.

## Build and validation
`npm test` runs the regression suite. `npm run build:web` produces the deterministic Capacitor `www` directory. GitHub Actions installs dependencies, tests, builds the web bundle, adds Android if absent, applies native Sable branding and uploads a debug APK artifact.

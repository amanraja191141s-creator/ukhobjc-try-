# Sable Calculator v101.0 — QA report

## Rebuild scope
- Replaced the earlier blue/navy and warm-paper presentation with the Porcelain / Forest / Signal Lime visual system.
- Changed primary navigation to Compute / Library / Trail / Studio.
- Removed the separate Saved bottom tab and old drawer/menu affordances from the visible shell.
- Replaced the tile-based tool dashboard with a searchable, category-filtered single-column task index.
- Made the calculator expression/result display an open canvas rather than a framed card.
- Added Choice Compare as the 24th tool and a dedicated calculation screen.
- Retained the existing calculation, currency provider/refresh, scientific, unit, finance, date, history and settings engines.

## Verification completed in this build environment
- 102/102 automated tests passed.
- JavaScript syntax checks passed for all app, service-worker, server and build scripts.
- CSS parsed with zero parser errors across 288 top-level rules.
- HTML parsed; no duplicate IDs.
- 24 tool cards found; all 24 link to an existing screen; no duplicate HTML IDs.
- Choice Compare engine validated for totals, winner, difference, crossover and input boundaries.
- Android web bundle generated successfully; 14 required source assets verified.
- GitHub Actions YAML parsed successfully.
- Package, HTML and manifest version synchronized to `2.01.0-v101.0`; service-worker cache namespace bumped.
- ZIP integrity passed; the extracted ZIP passed all 102 tests and regenerated the Android web bundle successfully.

## Research scope
Public product material for 23 calculator apps plus Omni Calculator as a web reference was reviewed, including Google Calculator, Samsung Calculator, ClevCalc, HiPER, RealCalc, Desmos Scientific, Desmos Graphing, GeoGebra, Wolfram|Alpha, Calculator Plus, All-In-One Calculator, CalcKit, CalcKit.io, PCalc, Calzy, Soulver, Calca, MyScript Calculator 2, Mathlab, Calculator++, CALCU, Fossify Calculator, NCalc and Omni Calculator.
This is public-page desk research, not identical-device hands-on benchmarking of every app.

## Not yet verified
- Live GitHub Actions execution and actual Android APK artifact generation.
- Installation and runtime validation on a physical Android handset.
- Visual screenshot review across multiple Android OEMs, display densities and font scaling.
- TalkBack/manual accessibility audit.
- Sustained frame-time, memory and thermal/performance benchmarking.
- Live currency provider connectivity with production API credentials.

Passing automated tests does not prove zero defects or zero lag on every Android device. Those claims require physical-device and live-service testing.

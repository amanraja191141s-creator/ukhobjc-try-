import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync('index.html','utf8');
const app=fs.readFileSync('assets/js/app.js','utf8');
const addon=fs.readFileSync('assets/js/sable-calculators.js','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8');
const workflow=fs.readFileSync('.github/workflows/main.yml','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const manifest=JSON.parse(fs.readFileSync('manifest.webmanifest','utf8'));

test('Sable v101 identity is synchronized',()=>{
 assert.equal(pkg.name,'sable-calculator');
 assert.equal(pkg.version,'2.01.0-v101.0');
 assert.match(html,/Sable/); assert.match(html,/2\.01\.0-v101\.0/);
 assert.equal(manifest.name,'Sable Calculator');
 assert.match(fs.readFileSync('service-worker.js','utf8'),/sable-calculator-v101-0-workbench-v1010/);
});

test('v101 workbench palette replaces the former blue, navy and warm-paper themes',()=>{
 assert.match(css,/--paper:#f2f5f0/);
 assert.match(css,/--accent:#c8e85b/);
 assert.match(css,/--key:#e5ece5/);
 assert.doesNotMatch(css,/#1976d2|#4d5cff|#0088cc/);
 assert.match(html,/sable-brand-mark/);
 assert.match(html,/CALCULATION WORKBENCH/);
});

test('new primary navigation exposes Compute, Library, Trail and Studio only',()=>{
 const nav=html.slice(html.indexOf('id="bottom-navigation"'),html.indexOf('</nav>',html.indexOf('id="bottom-navigation"')));
 const visible=[...nav.matchAll(/data-bottom-nav="(calc|tools|history|settings)"/g)].map(m=>m[1]);
 assert.deepEqual(visible,['calc','tools','history','settings']);
 assert.match(nav,/>Compute</); assert.match(nav,/>Library</); assert.match(nav,/>Trail</); assert.match(nav,/>Studio</);
 assert.doesNotMatch(nav,/favorites|sable-saved-compat/);
});

test('theme preferences are real and the former forced-blue lock is removed',()=>{
 assert.match(app,/function applySettingTheme\(val\) \{\s*if \(!\['light', 'dark', 'system'\]\.includes\(val\)\) val = 'light'/);
 assert.match(app,/theme: 'light'/);
 assert.match(app,/settingsFormatVersion: 4/);
 assert.match(app,/v4 retires the v100 warm-paper\/persimmon palette/);
 assert.match(app,/accentColor: '#c8e85b'/);
 assert.doesNotMatch(app,/val = 'dark'|color = '#4d5cff'|#1976d2|#087fff/);
 assert.equal((html.match(/class="theme-option"/g)||[]).length,6);
 assert.match(css,/html\.oled-theme,body\.oled-theme/);
});

test('Saved tools are integrated into Explore and can return to the library',()=>{
 assert.match(html,/id="btn-open-saved-tools"/);
 assert.match(html,/id="btn-favorites-back"/);
 assert.match(app,/btn-open-saved-tools/);
 assert.match(app,/btn-favorites-back/);
 assert.match(app,/switchScreen\('favorites'\)/);
});

test('all existing calculator destinations remain present and reachable',()=>{
 const screens=[...html.matchAll(/id="screen-([^"]+)"/g)].map(m=>m[1]);
 for(const s of ['calc','scientific','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','billsplit','compoundgrowth','markupmargin','ratiosplit','quickstats','timespan','tools','favorites','settings']) assert.ok(screens.includes(s),`missing ${s}`);
 assert.equal((html.match(/data-tool-screen="/g)||[]).length,24);
 for(const id of ['billsplit','compoundgrowth','markupmargin','ratiosplit','quickstats','timespan','choicecompare']) assert.match(app,new RegExp(`id: '${id}'`));
});

test('new style system covers all primary surfaces, forms, tools, settings and accessibility',()=>{
 for(const token of ['.calc-display','.main-keypad','.premium-tool-card','.settings-row','.reference-field','.scientific-display','#history-modal','.sable-navigation','prefers-reduced-motion:reduce']) assert.ok(css.includes(token),`missing style ${token}`);
 assert.match(css,/@media\(max-width:360px\)/);
 assert.match(css,/focus-visible/);
});

test('calculation engines and currency refresh systems remain wired to their existing UI controls',()=>{
 for(const token of ['formatCurrencyRefreshTimestamp','renderCurrencyRefreshTimes','initBottomNavigation','function switchScreen','calcLoan','calcDiscount']) assert.ok(app.includes(token),`missing engine ${token}`);
 for(const token of ['billSplit','compoundGrowth','markupMargin','ratioSplit','quickStats','timeSpan','choiceCompare']) assert.ok(addon.includes(token),`missing new calculator ${token}`);
 assert.match(html,/id="cur-refresh-time"/);
 assert.match(html,/id="cur-rate-status"/);
});

test('Android workflow builds only the Sable v101 release and uploads APK',()=>{
 assert.match(workflow,/2\.01\.0-v101\.0/);
 assert.match(workflow,/npm test/);
 assert.match(workflow,/npm run build:web/);
 assert.match(workflow,/npx cap add android/);
 assert.match(workflow,/sable-calculators\.js/);
 assert.match(workflow,/npm run android:brand/);
 assert.match(workflow,/npm run android:apk/);
 assert.match(workflow,/actions\/upload-artifact@v4/);
});

test('v101 introduces a working decision-first comparison calculator',()=>{
 assert.match(html,/id="screen-choicecompare"/);
 assert.match(html,/data-tool-screen="choicecompare"/);
 for(const id of ['cc-a-upfront','cc-a-monthly','cc-b-upfront','cc-b-monthly','cc-months','cc-result','cc-winner']) assert.match(html,new RegExp(`id="${id}"`));
 assert.match(addon,/choiceCompare\(/);
 assert.match(addon,/data-sable-calc/);
});

test('new interaction language is a task index, not a tile dashboard',()=>{
 assert.match(html,/THE CALCULATION INDEX/);
 assert.match(html,/Start with the question/);
 assert.match(css,/\.tools-group-grid\{display:flex;flex-direction:column;gap:0\}/);
 assert.match(css,/\.premium-tool-card\{width:100%;min-height:72px/);
 assert.match(css,/\.calc-display\{flex:1 1 155px;min-height:150px;max-height:40%;padding:18px 4px 16px;background:transparent;border:0/);
});

test('all six new accent names match the runtime palette map',()=>{
 const names=[...html.matchAll(/data-theme-name="([^"]+)"/g)].map(m=>m[1]);
 assert.deepEqual(names,['Signal Lime','Field Moss','Mist Stone','Iris','Saffron','Lagoon']);
 for(const name of names) assert.match(app,new RegExp(`'${name}': '#[0-9a-f]{6}'`));
 assert.doesNotMatch(html,/Sable Ember|Quiet Sage|Harbor Slate|Soft Plum|Warm Marigold|Deep Teal/);
});

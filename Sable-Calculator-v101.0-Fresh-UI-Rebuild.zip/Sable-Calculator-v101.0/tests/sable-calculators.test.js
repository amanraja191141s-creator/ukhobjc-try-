const test=require('node:test');
const assert=require('node:assert/strict');
const m=require('../assets/js/sable-calculators.js');

test('bill split applies tip and tax to subtotal and divides evenly',()=>{
 const r=m.billSplit({subtotal:1200,tip:10,tax:5,people:4});
 assert.equal(r.tipAmount,120);assert.equal(r.taxAmount,60);assert.equal(r.total,1380);assert.equal(r.each,345);
});
test('bill split rejects fractional or zero people',()=>{
 assert.throws(()=>m.billSplit({subtotal:10,tip:0,tax:0,people:0}),/People/);
 assert.throws(()=>m.billSplit({subtotal:10,tip:0,tax:0,people:1.5}),/whole number/);
 assert.throws(()=>m.billSplit({subtotal:'',tip:0,tax:0,people:1}),/required/);
});
test('compound growth supports monthly and annual compounding',()=>{
 const monthly=m.compoundGrowth({principal:10000,rate:8,years:5,frequency:12});
 const annual=m.compoundGrowth({principal:10000,rate:8,years:5,frequency:1});
 assert.ok(monthly.future>annual.future);assert.ok(monthly.interest>0);
});
test('compound growth rejects unsupported frequency and non-finite output',()=>{
 assert.throws(()=>m.compoundGrowth({principal:1,rate:2,years:1,frequency:2}),/frequency/);
 assert.throws(()=>m.compoundGrowth({principal:-1,rate:2,years:1,frequency:12}),/Starting amount/);
});
test('markup and gross margin use different denominators',()=>{
 const r=m.markupMargin({cost:750,selling:1000});
 assert.equal(r.profit,250);assert.ok(Math.abs(r.markup-100/3)<1e-12);assert.equal(r.margin,25);
 assert.equal(m.markupMargin({cost:0,selling:100}).markup,null);
});
test('ratio split conserves the total',()=>{
 const r=m.ratioSplit({total:1000,a:2,b:3});
 assert.equal(r.a+r.b,1000);assert.equal(r.a,400);assert.equal(r.b,600);
 assert.throws(()=>m.ratioSplit({total:1,a:0,b:0}),/ratio/);
});
test('quick statistics calculate mean, median, range and population deviation',()=>{
 const r=m.quickStats({values:'12, 18, 21, 25, 34'});
 assert.equal(r.count,5);assert.equal(r.mean,22);assert.equal(r.median,21);assert.equal(r.range,22);
 assert.ok(Math.abs(r.standardDeviation-Math.sqrt(54))<1e-12);
});
test('quick statistics accept negatives and reject malformed or excessive lists',()=>{
 assert.equal(m.quickStats({values:'-2 0 2'}).mean,0);
 assert.throws(()=>m.quickStats({values:'1, nope, 3'}),/valid numbers/);
 assert.throws(()=>m.quickStats({values:Array(10001).fill('1').join(',')}),/10,000/);
});
test('time span handles multi-day intervals and rejects reversed endpoints',()=>{
 const r=m.timeSpan({start:'2026-11-01T09:00',end:'2026-11-02T10:30'});
 assert.equal(r.minutes,1530);assert.equal(r.duration,'1d 1h 30m');
 assert.throws(()=>m.timeSpan({start:'2026-11-02T10:00',end:'2026-11-01T10:00'}),/after/);
});

test('choice compare totals upfront and recurring costs over the same period',()=>{
 const r=m.choiceCompare({aUpfront:12000,aMonthly:800,bUpfront:18000,bMonthly:450,months:24});
 assert.equal(r.aTotal,31200);assert.equal(r.bTotal,28800);assert.equal(r.difference,2400);assert.equal(r.winner,'Option B');
 assert.equal(r.breakEven,17.142857142857142);
});
test('choice compare validates whole bounded periods and non-negative inputs',()=>{
 assert.throws(()=>m.choiceCompare({aUpfront:-1,aMonthly:1,bUpfront:1,bMonthly:1,months:12}),/Option A upfront/);
 assert.throws(()=>m.choiceCompare({aUpfront:1,aMonthly:1,bUpfront:1,bMonthly:1,months:1.5}),/whole number/);
 assert.throws(()=>m.choiceCompare({aUpfront:1,aMonthly:1,bUpfront:1,bMonthly:1,months:1201}),/1,200/);
});

test('choice compare rejects totals that overflow numeric precision',()=>{
 assert.throws(()=>m.choiceCompare({aUpfront:1e308,aMonthly:1e308,bUpfront:1,bMonthly:1,months:1200}),/supported calculation range/);
});

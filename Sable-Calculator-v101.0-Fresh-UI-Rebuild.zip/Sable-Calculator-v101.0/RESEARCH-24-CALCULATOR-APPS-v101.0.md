# Sable v101.0 — 23 calculator-apps plus one web calculator desk research and design decisions

Research date: 19 November 2026. Scope: public product descriptions, vendor documentation and app-store feature pages, supplemented by current first-party app listings. This is desk research, not a claim that 24+ apps were installed and benchmarked on identical devices.

## Apps reviewed (23)

| Product | Strong design/product signal considered |
|---|---|
| Google Calculator | Low-friction everyday arithmetic and uncluttered entry |
| Samsung Calculator | Clear separation of standard, engineering and history workflows |
| ClevCalc | Broad everyday utility coverage and categorized calculators |
| HiPER Scientific Calculator | Dense scientific capability, expression editing and advanced math |
| RealCalc Scientific Calculator | Familiar physical-calculator interaction and optional RPN |
| Desmos Scientific Calculator | Persistent visible expressions and answer reuse |
| Desmos Graphing Calculator | Graph-first exploration for functions |
| GeoGebra Calculator Suite | Linked algebra, graph, table and graphics views |
| Wolfram|Alpha | Knowledge-backed and stepwise mathematical exploration |
| Calculator Plus with History | Practical household and financial calculations with history |
| All-In-One Calculator | Wide calculator/converter catalog and multi-currency conversion |
| CalcKit | Search, recently used tools, favorites and offline-first utility flow |
| CalcKit.io | Fast access to a broad catalog and custom calculators |
| PCalc | Layout choice, paper tape, RPN, memory and conversion tools |
| Calzy | Memory area, bookmarks, basic/advanced modes and privacy |
| Soulver | Calculation notes with named expressions and contextual results |
| Calca | Math-document workflow with variables and reusable expressions |
| MyScript Calculator 2 | Paper-like multi-line calculation and direct manipulation |
| Mathlab Graphing Calculator | Graphing and algebra-oriented workflow |
| Calculator++ | Configurable scientific calculator and widget-style access |
| CALCU | Theme/personalization-led calculator experience |
| Fossify Calculator | Local-first privacy and minimal permission model |
| NCalc | Scientific calculator workflow and configurable math functions |
| Omni Calculator | Task-specific web calculators, explanatory inputs and shareable results |

## Cross-app observations

1. **Entry speed matters:** everyday calculator screens prioritize a visible expression, a legible result and reachable numeric keys. Scientific functions should not crowd the default keypad.
2. **History is a workflow, not a dump:** reuse, copy, edit and delete actions make past calculations useful. Sable exposes this as Activity.
3. **Tools need intent-based discovery:** broad catalogs benefit from search, grouping and saved/recent shortcuts. Sable uses task groups rather than a long unstructured list.
4. **Advanced modes should be progressive:** scientific and specialist tools remain separate destinations, not a permanently dense keypad.
5. **Input/result hierarchy must survive small screens:** long expressions and large results need independent sizing and overflow control.
6. **Themes are system-wide:** surfaces, fields, keypad, navigation, status and dialogs need shared tokens, not per-screen color patches.
7. **Offline and privacy expectations should be explicit:** calculations stay local where possible; live exchange rates are a network-dependent exception.
8. **No single app should be copied:** Sable uses a new warm-paper / graphite / persimmon palette, a four-destination navigation model and its own naming/content hierarchy. The research informed general interaction principles only.

## Sable's independent design direction

- Visual identity: warm mineral paper, deep graphite, persimmon action color and a restrained sage success color.
- Primary navigation: Desk / Explore / Activity / Profile.
- Saved calculators: integrated into Explore, not a separate bottom-level destination.
- Calculator: paper-like display surface, dark tactile key field, high-contrast equals action, adaptive result sizing.
- Tool discovery: query-first library, intent categories, task descriptions and dedicated workspaces.
- Settings: one consistent field and row language, with light/dark palettes sharing the same semantic tokens.
- Responsive behavior: safe-area aware navigation, narrow-screen layout, reduced-motion support and visible focus states.

## Evidence / source pages

- Google Play: ClevCalc — https://play.google.com/store/apps/details?id=com.dencreak.dlcalculator
- Google Play: Samsung Calculator — https://play.google.com/store/apps/details?id=com.sec.android.app.popupcalculator
- Google Play: HiPER — https://play.google.com/store/apps/details?id=cz.hipercalc
- Google Play: RealCalc — https://play.google.com/store/apps/details?id=uk.co.nickfines.RealCalc
- Google Play: Desmos Scientific — https://play.google.com/store/apps/details?id=com.desmos.scientific
- GeoGebra product documentation — https://help.geogebra.org/hc/en-us/articles/10445800380957-GeoGebra-Tools-and-Features-An-Overview
- PCalc official feature page — https://pcalc.com/ios/
- Calzy App Store page — https://apps.apple.com/in/app/calzy/id623690732
- MyScript Calculator 2 — https://play.google.com/store/apps/details?id=com.myscript.calculator
- Calculator Plus — https://play.google.com/store/apps/details?id=com.digitalchemy.calculator.freedecimal
- CalcKit — https://play.google.com/store/apps/details?id=com.yasirulakmal.calckit
- CalcKit.io — https://play.google.com/store/apps/details?id=com.ivanGavrilov.CalcKit
- All-In-One Calculator — https://play.google.com/store/apps/details?id=all.in.one.calculator
- App comparison and further references — https://www.itechguides.com/10-best-calculator-apps-for-android-scientific-graphing-and-everyday-picks/


## v101.0 deeper product comparison

| Product family / apps | Observed strength from public product material | Design implication for Sable |
|---|---|---|
| Everyday: Google Calculator, Samsung Calculator, Calculator++, CALCU, Fossify Calculator | Fast entry, compact keypad, familiar arithmetic; Samsung exposes engineering and history as separate actions | Keep Compute focused; do not put every advanced control on the first screen |
| Scientific: HiPER, RealCalc, Desmos Scientific, NCalc, Mathlab, PCalc | Editable expressions, precision, memory, RPN or specialist functions | Keep scientific tools in their own workspace and preserve expression editing |
| Graphing / symbolic: Desmos Graphing, GeoGebra, Wolfram|Alpha, Symbolab, Mathway, Photomath | Graph-first exploration, sliders, equation properties, symbolic or stepwise help | Avoid pretending the standard keypad is a graphing or CAS tool; label capabilities accurately |
| Multi-tool: ClevCalc, Calculator Plus, All-In-One Calculator, CalcKit, CalcKit.io | Large tool catalogs, category grouping, search, currency/unit conversion and reusable history | Make discovery task-led and searchable, not a dense, unstructured wall of tiles |
| Notes / memory: Calzy, Soulver, Calca, MyScript Calculator 2 | Bookmarks, named values, natural-language worksheets, handwriting and result reuse | Make results reusable and named; preserve a clear expression-to-result relationship |
| Specialized reference: Omni Calculator | Dedicated task calculators with context-specific inputs and explanation | Each workspace should explain what it calculates and why each input is needed |

### v101 design decisions

1. **Question-first Library:** a single-column index with task descriptions makes the 24 workspaces scannable without reproducing a competitor's tile layout.
2. **Open calculation canvas:** the expression and result sit on the page itself; no rounded display container competes with the answer.
3. **Compute / Library / Trail / Studio:** the navigation describes user intent rather than mirroring the common Calculator / Tools / History / Settings sequence.
4. **Choice Compare:** a new local calculator compares upfront plus recurring cost, making a decision rather than merely returning one arithmetic value.
5. **No permanent blue identity:** the new porcelain / forest / signal-lime tokens are applied to every surface and theme.
6. **Progressive disclosure:** scientific and specialist controls stay in dedicated workspaces; the default keypad remains simple.
7. **Offline-first behavior:** ordinary calculations stay local; currency refresh remains explicitly network-dependent.

The product signals above are paraphrased from public listings and product documentation. They are not claims that every app was visually benchmarked on the same handset or that all features are available in every current release.

### Scope clarification
The 23 named calculator apps are the mobile-app comparison set. Omni Calculator is an additional web-based calculator reference, not counted as a mobile app. Public listings are snapshots; feature availability can differ by platform, region and app version.


### Additional first-party product pages consulted during v101 review
- Google Calculator — https://play.google.com/store/apps/details?id=com.google.android.calculator
- Samsung Calculator — https://play.google.com/store/apps/details?id=com.sec.android.app.popupcalculator
- Desmos Graphing Calculator — https://play.google.com/store/apps/details?id=com.desmos.calculator
- GeoGebra Graphing Calculator — https://play.google.com/store/apps/details?id=org.geogebra.android
- Symbolab Graphing Calculator — https://play.google.com/store/apps/details?id=com.symbolab.graphingcalculator
- Calzy feature page — https://www.calzy.app/
- Calzy App Store listing — https://apps.apple.com/in/app/calzy/id623690732
- MyScript Calculator 2 — https://play.google.com/store/apps/details?id=com.myscript.calculator
- PCalc official feature page — https://pcalc.com/ios/
- CalcKit scientific calculator documentation — https://calckit.io/docs/calculator

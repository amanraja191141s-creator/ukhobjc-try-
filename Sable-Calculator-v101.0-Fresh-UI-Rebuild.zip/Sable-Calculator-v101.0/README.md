# Sable Calculator v101.0 — Calculation Workbench

Sable v101 replaces the previous visual shell with a distinct question-first calculation workbench. The release uses a porcelain / forest / signal-lime design system, open expression canvas, single-column task library and four-purpose navigation.

## What changed
- New visual identity: porcelain `#f2f5f0`, forest ink `#17231f`, signal lime `#c8e85b`.
- New navigation: Compute, Library, Trail and Studio.
- Removed the visible legacy drawer/menu entry points and separate Saved bottom tab.
- Replaced the tile dashboard with a searchable, category-filtered task index.
- Rebuilt calculator display, keypad, tool rows, forms, results, history and settings styling.
- Added Choice Compare, the 24th tool: compare two options using upfront and recurring costs over a bounded month range.
- Added a v4 settings migration to retire previously saved v100 accent/theme values.
- Bumped service-worker cache and Android release identity to `2.01.0-v101.0`.

## App structure
- **Compute:** open calculation canvas, live expression/result and keypad.
- **Library:** 24 focused workspaces across Convert, Finance, Math and Daily.
- **Trail:** calculation history and reuse actions.
- **Studio:** appearance, number formatting, startup behavior, input feedback, privacy and preferences.
- **Pinned workspaces:** saved calculator shortcuts inside Library, not a bottom navigation destination.

## Calculator content
Basic and scientific calculation, currency and unit conversion, discount, percentage, sales tax, body metrics, date, fuel cost, fuel efficiency, grade average, hexadecimal, loan, savings, tip, unit price, world time, bill split, compound growth, markup & margin, ratio split, quick statistics, time span and Choice Compare.

Existing calculation, currency-provider/refresh, scientific, unit, finance, date, history and settings engines are retained as a compatibility core. The presentation layer and navigation are replaced; the release does not claim every underlying engine was rewritten from scratch.

## Research
The desk-research file compares 23 calculator apps plus Omni Calculator as a web reference. It uses public store listings and product documentation; it is not a claim of identical-device hands-on testing of every competitor.

## Build locally
Requirements: Node.js 22, Java 21, Android SDK/Gradle for APK builds.

```bash
npm install
npm test
npm run build:web
npx cap add android
npm run android:brand
npm run android:apk
```

If the Android platform already exists, skip `npx cap add android`.

## GitHub Actions
Upload the complete extracted project to the repository root, including `.github/workflows/main.yml`, then run **Sable Calculator v101.0 — Android Release** from the Actions tab. The workflow runs tests, prepares the web bundle, creates a debug APK and uploads it as an artifact.

## QA limits
Automated tests and static build checks do not replace a physical Android device test. Actual GitHub Actions APK generation, installation across OEM devices, TalkBack, font scaling and sustained performance benchmarking remain separate release checks.

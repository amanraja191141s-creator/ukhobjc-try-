(function sableCalculators(global) {
  'use strict';
  const money = value => new Intl.NumberFormat(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
  const pct = value => `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value)}%`;
  const finite = (value, label, min = -Infinity) => {
    if (value === null || value === undefined || String(value).trim() === '') throw new Error(`${label} is required.`);
    const n = Number(value);
    if (!Number.isFinite(n) || n < min) throw new Error(`${label} must be ${min >= 0 ? 'zero or greater' : 'a valid number'}.`);
    return n;
  };
  const calculators = {
    billSplit({ subtotal, tip, tax, people }) {
      const s=finite(subtotal,'Bill subtotal',0), t=finite(tip,'Tip',0), x=finite(tax,'Tax',0), p=finite(people,'People',1);
      if (!Number.isInteger(p) || p>10000) throw new Error('People must be a whole number from 1 to 10,000.');
      const tipAmount=s*t/100, taxAmount=s*x/100, total=s+tipAmount+taxAmount;
      return { each:total/p,total,tipAmount,taxAmount };
    },
    compoundGrowth({ principal, rate, years, frequency }) {
      const p=finite(principal,'Starting amount',0), r=finite(rate,'Annual rate',0), y=finite(years,'Years',0), n=finite(frequency,'Compounding',1);
      if (![1,4,12,365].includes(n)) throw new Error('Choose a supported compounding frequency.');
      const future=p*Math.pow(1+(r/100)/n,n*y);
      if (!Number.isFinite(future)) throw new Error('This projection is too large to calculate.');
      return { future, interest:future-p };
    },
    markupMargin({ cost, selling }) {
      const c=finite(cost,'Cost price',0), s=finite(selling,'Selling price',0);
      if (s===0) throw new Error('Selling price must be greater than zero.');
      const profit=s-c;
      return { profit, markup:c===0?null:profit/c*100, margin:profit/s*100 };
    },
    ratioSplit({ total, a, b }) {
      const t=finite(total,'Total'), x=finite(a,'Part A',0), y=finite(b,'Part B',0);
      if (x+y===0) throw new Error('At least one ratio part must be greater than zero.');
      return { a:t*x/(x+y), b:t*y/(x+y) };
    },
    quickStats({ values }) {
      const raw=String(values??'').trim();
      if (!raw) throw new Error('Enter at least one number.');
      const parts=raw.split(/[,\s;]+/).filter(Boolean);
      if (parts.length>10000) throw new Error('Use up to 10,000 values at a time.');
      const nums=parts.map(Number);
      if (nums.some(n=>!Number.isFinite(n))) throw new Error('Use only valid numbers separated by commas or spaces.');
      const sorted=[...nums].sort((a,b)=>a-b), count=nums.length, mean=nums.reduce((a,b)=>a+b,0)/count;
      const mid=Math.floor(count/2), median=count%2?sorted[mid]:(sorted[mid-1]+sorted[mid])/2;
      const min=sorted[0], max=sorted[count-1], variance=nums.reduce((sum,n)=>sum+(n-mean)**2,0)/count;
      if(!Number.isFinite(mean)||!Number.isFinite(variance)) throw new Error('The entered values exceed the supported calculation range.');
      return { mean,median,range:max-min,standardDeviation:Math.sqrt(variance),count,min,max };
    },
    timeSpan({ start, end }) {
      const a=Date.parse(start), b=Date.parse(end);
      if (!Number.isFinite(a)||!Number.isFinite(b)) throw new Error('Choose both a valid start and end time.');
      if (b<a) throw new Error('End time must be after the start time.');
      const minutes=Math.floor((b-a)/60000), days=Math.floor(minutes/1440), hours=Math.floor((minutes%1440)/60), mins=minutes%60;
      return { minutes,duration:days?`${days}d ${hours}h ${mins}m`:hours?`${hours}h ${mins}m`:`${mins}m` };
    },
    choiceCompare({ aUpfront, aMonthly, bUpfront, bMonthly, months }) {
      const au=finite(aUpfront,'Option A upfront cost',0), am=finite(aMonthly,'Option A monthly cost',0);
      const bu=finite(bUpfront,'Option B upfront cost',0), bm=finite(bMonthly,'Option B monthly cost',0);
      const n=finite(months,'Comparison period',1);
      if(!Number.isInteger(n)||n>1200) throw new Error('Comparison period must be a whole number from 1 to 1,200 months.');
      const aTotal=au+am*n, bTotal=bu+bm*n, difference=Math.abs(aTotal-bTotal);
      if(!Number.isFinite(aTotal)||!Number.isFinite(bTotal)||!Number.isFinite(difference)) throw new Error('The compared costs exceed the supported calculation range.');
      const monthlyDelta=am-bm, upfrontDelta=bu-au;
      let breakEven=null;
      if(monthlyDelta!==0) {
        const raw=upfrontDelta/monthlyDelta;
        if(Number.isFinite(raw)&&raw>=0) breakEven=raw;
      }
      return {aTotal,bTotal,difference,winner:aTotal===bTotal?'Equal cost':aTotal<bTotal?'Option A':'Option B',breakEven,months:n};
    }
  };
  global.SableMath=calculators;
  if (typeof module!=='undefined'&&module.exports) module.exports=calculators;

  function run(type, screen) {
    const get=id=>screen.querySelector(`#${id}`);
    const text=(id,value)=>{const el=get(id);if(el)el.textContent=value;};
    const show=(id)=>{const el=get(id);if(el)el.hidden=false;};
    const feedback=screen.querySelector('[data-sable-feedback]');
    try {
      if(feedback){feedback.hidden=true;feedback.textContent='';}
      let result;
      if(type==='billsplit') {
        result=calculators.billSplit({subtotal:get('bs-subtotal').value,tip:get('bs-tip').value,tax:get('bs-tax').value,people:get('bs-people').value});
        text('bs-each',money(result.each));text('bs-total',money(result.total));text('bs-tip-amount',money(result.tipAmount));text('bs-tax-amount',money(result.taxAmount));show('bs-result');
      } else if(type==='compoundgrowth') {
        result=calculators.compoundGrowth({principal:get('cg-principal').value,rate:get('cg-rate').value,years:get('cg-years').value,frequency:get('cg-frequency').value});
        text('cg-future',money(result.future));text('cg-interest',money(result.interest));show('cg-result');
      } else if(type==='markupmargin') {
        result=calculators.markupMargin({cost:get('mm-cost').value,selling:get('mm-selling').value});
        text('mm-profit',money(result.profit));text('mm-markup',result.markup===null?'Not defined':pct(result.markup));text('mm-margin',pct(result.margin));show('mm-result');
      } else if(type==='ratiosplit') {
        result=calculators.ratioSplit({total:get('rs-total').value,a:get('rs-a').value,b:get('rs-b').value});
        text('rs-out-a',money(result.a));text('rs-out-b',money(result.b));show('rs-result');
      } else if(type==='quickstats') {
        result=calculators.quickStats({values:get('qs-values').value});
        text('qs-mean',money(result.mean));text('qs-median',money(result.median));text('qs-range',money(result.range));text('qs-sd',money(result.standardDeviation));text('qs-count',String(result.count));show('qs-result');
      } else if(type==='timespan') {
        result=calculators.timeSpan({start:get('ts-start').value,end:get('ts-end').value});
        text('ts-duration',result.duration);text('ts-minutes',new Intl.NumberFormat().format(result.minutes));show('ts-result');
      }
      else if(type==='choicecompare') {
        result=calculators.choiceCompare({aUpfront:get('cc-a-upfront').value,aMonthly:get('cc-a-monthly').value,bUpfront:get('cc-b-upfront').value,bMonthly:get('cc-b-monthly').value,months:get('cc-months').value});
        text('cc-winner',result.winner);text('cc-a-total',money(result.aTotal));text('cc-b-total',money(result.bTotal));text('cc-difference',money(result.difference));
        text('cc-breakeven',result.breakEven===null?'No crossover':`${new Intl.NumberFormat(undefined,{maximumFractionDigits:1}).format(result.breakEven)} months`);
        text('cc-explanation',result.winner==='Equal cost'?`Both options total ${money(result.aTotal)} over ${result.months} months.`:`${result.winner} is lower by ${money(result.difference)} over ${result.months} months.`);
        show('cc-result');
      }
    } catch(error) {
      if(feedback){feedback.textContent=error.message||'Check the entered values.';feedback.hidden=false;}
    }
  }
  function bind() {
    document.addEventListener('click',event=>{
      const back=event.target.closest('[data-sable-back]');
      if(back){if(typeof global.switchScreen==='function')global.switchScreen('tools');return;}
      const button=event.target.closest('[data-sable-calc]');
      if(!button)return;
      const screen=button.closest('.screen');
      if(screen)run(button.dataset.sableCalc,screen);
    });
  }
  if(typeof document!=='undefined') {
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind,{once:true});
    else bind();
  }
})(typeof globalThis!=='undefined'?globalThis:this);

/* Sable v101.0 starts in porcelain light mode; user theme preference remains changeable in Settings. */
(function bootstrapSableTheme() {
  const root = document.documentElement;
  root.style.colorScheme = 'light';
  root.setAttribute('data-theme', 'light');
  root.setAttribute('data-theme-mode', 'light');
  document.body?.setAttribute('data-theme', 'light');
  document.body?.setAttribute('data-theme-mode', 'light');
})();
